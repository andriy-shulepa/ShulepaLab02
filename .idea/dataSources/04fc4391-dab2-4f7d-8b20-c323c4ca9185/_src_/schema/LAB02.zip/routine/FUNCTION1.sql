CREATE FUNCTION       FUNCTION1 RETURN NUMBER IS val varchar2(100);
BEGIN
  SELECT '2'||to_char(SYSDATE, 'ddmmyyyyhh24miss')||TRUNC(DBMS_RANDOM.value(1000,9999))into val
  FROM SYS.DUAL;
  return trunc(to_number(val));
END FUNCTION1;
/
