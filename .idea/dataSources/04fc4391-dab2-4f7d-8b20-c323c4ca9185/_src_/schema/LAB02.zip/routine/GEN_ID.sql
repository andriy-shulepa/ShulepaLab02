CREATE FUNCTION       GEN_ID(table_id NUMBER) RETURN NUMBER IS val varchar2(50);
BEGIN
  SELECT table_id||to_char(SYSDATE, 'ddmmyyyyhh24miss')||TRUNC(DBMS_RANDOM.value(1000,9999))into val
  FROM SYS.DUAL;
  return trunc(to_number(val));
END GEN_ID;
/
