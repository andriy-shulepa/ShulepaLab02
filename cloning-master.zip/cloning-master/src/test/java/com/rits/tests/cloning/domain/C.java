package com.rits.tests.cloning.domain;

/**
 * @author kostantinos.kougios
 *
 * 30 Nov 2009
 */
public class C
{
	private int		x		= 5;
	private String	name	= "kostas";

	public int getX()
	{
		return x;
	}

	public void setX(final int x)
	{
		this.x = x;
	}

	public String getName()
	{
		return name;
	}

	public void setName(final String name)
	{
		this.name = name;
	}

	private int	y	= 7;

	public int getY()
	{
		return y;
	}

	public void setY(final int y)
	{
		this.y = y;
	}

}
