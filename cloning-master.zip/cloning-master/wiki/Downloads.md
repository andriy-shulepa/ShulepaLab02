Please download from the maven repository:

https://oss.sonatype.org/content/repositories/releases/uk/com/robust-it/cloning/